from django.urls import path
from .views import View

urlpatterns=[
    path('v1/',View,name='review')
]