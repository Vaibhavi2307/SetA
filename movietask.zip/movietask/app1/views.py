from django.shortcuts import render
from .models import Review
from .forms import ReviewModelForm

def View(request):
    template_name=('app1/review.html')
    form=ReviewModelForm(request.POST)
    if form.is_valid():
        form.save()
    context={form:'form'}
    return render(request,template_name,context)






