from django.db import models

class Review(models.Model):
    id=models.IntegerField(primary_key=True)
    movie_title=models.CharField(max_length=200,null=False)
    director=models.CharField(max_length=100,null=False)
    review_content=models.CharField(null=False)
    rating=models.IntegerField(null=False)
    createdAt=models.CharField()
    reviewer_email_id=models.CharField(unique=True)
    status=models.CharField()
    genres=models.CharField()

